package snippet;

import java.util.Scanner;

public class Task1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		guessRandomNumber( );
		 
	}
	public static void guessRandomNumber( )
	{
		
		//int randomNum = (int)(Math.random() * 101);
		int randomNum =1 + (int)(System.currentTimeMillis()%((100 - 1) + 1));
	    Scanner myObj = new Scanner(System.in);
	    System.out.println("Guess random number and enter here");
	    float num;
	    num = myObj.nextFloat();
	    if (num>randomNum)
	    {
	    	System.out.println("The number is too large");
	    }
	    else if (num<randomNum)
	    {
	    	System.out.println("The number is too small");
	    }
	    else
	    {
	    	System.out.println("Correct Number");
	    }
	    System.out.println("The randomly generated number is: "+randomNum );

	}

}
