package snippet;
import java.util.Scanner;
import java.util.ArrayList;

public class Task2 {

    public static void main(String[] args) {
    	Scanner myObj = new Scanner(System.in);
        System.out.println("Enter Your Full Name:");
        //Input Name
        String name = myObj.nextLine();
    	//Function Call
    	nameAbbrevation(name);

    }
    public static void nameAbbrevation(String name) 
    {
    	 
         String separated = "";         
         ArrayList<String> splittedName = new ArrayList<String>();   
         //Split the name into seprate words and save it in List

         for (int i = 0; i < name.length(); i++) {
             separated += name.charAt(i);
             if (name.charAt(i) == ' ') {                
                 splittedName.add(separated);
                 separated = "";
             }
         }
         //Save the Last Name in String
         if (!separated.isEmpty()) {
             splittedName.add(separated);
         }
         //splittedName.add(separated);
         
         //Display the Abbreviations except the last name

         for (int i = 0; i < splittedName.size() - 1; i++) {
             String part = splittedName.get(i);
             System.out.print(part.charAt(0) + ".");
         }
         
         System.out.print(splittedName.get(splittedName.size() - 1));
    }
}






