package snippet;
import java.util.ArrayList;
import java.util.Scanner;
public class Task4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String substr="";
		Scanner myObj = new Scanner(System.in);
        System.out.println("Enter the string");
        String inputStr = myObj.nextLine();  		
		ArrayList<String> subStrings = new ArrayList<String>();
		ArrayList<String> palindromes = new ArrayList<String>();
		  
		   for (int i = 0; i < inputStr.length(); i++) {
		   for (int j = i+1; j <= inputStr.length(); j++) {
			   substr=inputStr.substring(i,j);			   		        
		         subStrings.add(substr);		 
		   }
		   }
		   for(int i=0;i<subStrings.size();i++)
		   {
			   System.out.println(subStrings.get(i));
		   }
		   
		   for(int i=0;i<subStrings.size();i++)
		   {
			   String element=subStrings.get(i);
			   boolean palin=true;
			   for (int j=0; j<=(element.length()-1)/2;j++)
			   {
				   if(element.charAt(j)!=element.charAt(element.length()-1-j))
				   {
					   palin=false;
				   }
			   }
			   if(palin)
			   {
				   palindromes.add(element);
			   }
		   }
		   String maxPalin="";
		   for (int i=0; i<palindromes.size();i++)
		   {
			   if(palindromes.get(i).length()>maxPalin.length())
			   {
				   maxPalin=palindromes.get(i);
			   }
		   }
		   if(maxPalin.length()>1)
		   {
			   System.out.println("Longest Palindrome is: "+maxPalin);
		   }
		   else
		   {
		   System.out.println("No Palindrome Exists");
		   }

	}

}
