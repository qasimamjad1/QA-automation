package snippet;
import java.util.ArrayList;

import java.util.Scanner;

public class Task3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Input the string
		Scanner myObj = new Scanner(System.in);
        System.out.println("Enter the string");
        String name = myObj.nextLine();
        //Function Call
        apphabetsCounter(name);
        

	}
	public static void apphabetsCounter(String name) {
		      
        ArrayList<Integer> counts = new ArrayList<Integer>(); 
        String newstr=""; 
        int max=0;
        //Save non repeated alphabets in new string and their occurance in List
        for (int i=0; i < name.length(); i++)
        {
        	boolean duplicate=false;
        	char character=name.charAt(i);
        	for (int j=0;j<newstr.length();j++)
        	{       		
        		if(character==newstr.charAt(j))
        		{
        			//Update the count of repeated number
        			duplicate=true;
        			int increment=counts.get(j);
        			counts.set(j, increment + 1);
        			//counts.get(j)=counts.get(j)+1;
        		}        		
        	}
        	if(!duplicate)
    		{
    			newstr+=character;
    			counts.add(1);
    		}       	
        }
        //Display all the numbers with count
        System.out.println("The occurrences of all alphabets is: ");
        for (int i=0;i<newstr.length();i++)
        {
        	System.out.println("Character: "+newstr.charAt(i)+" : frequency "+counts.get(i)+ " times");
        }
        for (int i=0;i<counts.size();i++)
        {
        	if(counts.get(i)>max)
        	{
        		max=counts.get(i);
        	}
        	
        }
        //Display all the alphabets with maximum occurrence
        System.out.println("\nThe alphabets with maximum occurance "+max+" are: ");
        for (int i=0;i<counts.size();i++)
        {
        	if(counts.get(i)==max)
        	{
        		System.out.println(newstr.charAt(i));
        	}
        	
        }
        
	}

}
