package snippet;
import java.util.ArrayList;

import java.util.Scanner;

public class Task5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner myObj = new Scanner(System.in);
        System.out.println("Enter the string");
        String name = myObj.nextLine();      
        
        String newstr="";        
        for (int i=0; i < name.length(); i++)
        {
        	boolean duplicate=false;
        	char character=name.charAt(i);
        	for (int j=0;j<newstr.length();j++)
        	{       		
        		if(character==newstr.charAt(j))
        		{
        			duplicate=true;
        		}        		
        	}
        	if(!duplicate)
    		{
    			newstr+=character;    			
    		}       	
        }
        System.out.println(newstr);
        

	}

}
