package Assignment5;
import io.github.bonigarcia.wdm.WebDriverManager;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import java.io.File;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.TakesScreenshot;

public class Assignment5 {
    public static Logger logger = Logger.getLogger("test1");
    public static void main(String[] args) {
        // Configure log4j properties file
        PropertyConfigurator.configure("Log4j.properties");
        
        // Open the Chrome browser and navigate to the base URL
        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        ChromeDriver driver = new ChromeDriver(options);
        String baseUrl = "https://omayo.blogspot.in/";
        driver.get(baseUrl);
        logger.info("Website has been opened");
        
        // Take a screenshot and save it to a file
        File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        try {
            FileUtils.copyFile(scrFile, new File("c:\\Screenshots\\screenshot1.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        // Multi Select Menu
        Select carMaker = new Select(driver.findElement(By.xpath("//select[contains(@id,'multiselect')]")));
        carMaker.selectByVisibleText("Hyundai"); 
        logger.info("Car Maker selected as Hyundai");
        // Capture a screenshot after selecting the car maker
        File scrFile2 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        try {
            FileUtils.copyFile(scrFile2, new File("c:\\Screenshots\\screenshot2.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        // Drop Down Menu
        Select dropDownMenu = new Select(driver.findElement(By.xpath("//select[@class='combobox']")));
        dropDownMenu.selectByIndex(3);
        logger.info("Dropdown option selected as doc3");
        // Capture a screenshot after selecting the dropdown option
        File scrFile3 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        try {
            FileUtils.copyFile(scrFile3, new File("c:\\Screenshots\\screenshot3.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        // PreLoaded Box
        WebElement preLoadedBox = driver.findElement(By.xpath("//input[@value='Selenium WebDriver']"));
        preLoadedBox.clear();
        preLoadedBox.sendKeys("Hello World");
        logger.info("Hello World written in preloaded box");
        // Capture a screenshot after typing in the preloaded box
        File scrFile4 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        try {
            FileUtils.copyFile(scrFile4, new File("c:\\Screenshots\\screenshot4.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        // Enabled Button
        WebElement enabledButton = driver.findElement(By.xpath("//button[contains(@id,'but')]"));
        enabledButton.click();
        logger.info("Enabled button clicked");
        // Capture a screenshot after clicking the enabled button
        File scrFile5 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        try {
            FileUtils.copyFile(scrFile5, new File("c:\\Screenshots\\screenshot5.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        // Three Buttons (Submit, Login, and Register)
        WebElement submitButton = driver.findElement(By.xpath("//button[@name='samename' and text()='Submit']"));
        WebElement loginButton = driver.findElement(By.xpath("//button[@name='samename' and text()='Login']"));
        WebElement registerButton = driver.findElement(By.xpath("//button[@name='samename' and text()='Register']"));
        
        // Click on each button and log the action
        submitButton.click(); 
        logger.info("Submit button clicked");
        loginButton.click(); 
        logger.info("Log in button clicked");
        registerButton.click(); 
        logger.info("Register button clicked");
        // Capture a screenshot after clicking the buttons
        File scrFile6 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        try {
            FileUtils.copyFile(scrFile6, new File("c:\\Screenshots\\screenshot6.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
