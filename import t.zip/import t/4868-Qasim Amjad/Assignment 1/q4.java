package q4;
//code converted from c# to java as it is 
public class q4 {

    // Function to check if a given substring is a palindrome
    private static boolean isPalindrome(String str, int start, int end) {
        while (start < end) {
            if (str.charAt(start) != str.charAt(end)) {
                return false;
            }
            start++;
            end--;
        }
        return true;
    }

    // Function to find the longest palindrome in a given string
    private static String findLongestPalindrome(String str) {
        int maxLength = 1; // Initialize the maximum palindrome length
        int start = 0; // Initialize the starting index of the longest palindrome

        // Iterate through each character in the string
        for (int i = 0; i < str.length(); i++) {
            // Check for odd length 
            for (int j = i - 1, k = i + 1; j >= 0 && k < str.length(); j--, k++) {
                if (isPalindrome(str, j, k)) {
                    if (k - j + 1 > maxLength) {
                        maxLength = k - j + 1;
                        start = j;
                    }
                } else {
                    break;
                }
            }

            for (int j = i, k = i + 1; j >= 0 && k < str.length(); j--, k++) {// Check for even length palindromes with centers at i and i+1

                if (isPalindrome(str, j, k)) {
                    if (k - j + 1 > maxLength) {
                        maxLength = k - j + 1;
                        start = j;
                    }
                } else {
                    break;
                }
            }
        }

        return str.substring(start, start + maxLength);
    }

    public static void main(String[] args) {
        String givenString = "qasimisaq";
        String longestPalindrome = findLongestPalindrome(givenString);

        System.out.println("Input: " + givenString);
        System.out.println("Output: " + longestPalindrome);
    }
}
