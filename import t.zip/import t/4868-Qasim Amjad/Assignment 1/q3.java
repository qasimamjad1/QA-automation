package q3;

import java.util.Scanner;

public class q3 {
    public static void main(String[] args) {
        Scanner a = new Scanner(System.in);

        System.out.print("Enter a string of alphabets: ");
        String b = a.nextLine().toLowerCase(); // Convert input to lowercase

        int[] c = new int[26]; // Array to store occurrences of each alphabet

        // Iterate through each character in the input string
        for (int d = 0; d < b.length(); d++) {
            char e = b.charAt(d);
            if (e >= 'a' && e <= 'z') { // Check if the character is an alphabet
                int f = e - 'a'; // Calculate the index in the occurrences array
                c[f]++; // Increment the occurrence count
            }
        }

        int g = 0;
        char h = ' ';

        // Find the alphabet with maximum occurrence
        for (int i = 0; i < 26; i++) {
            if (c[i] > g) {
                g = c[i];
                h = (char) ('a' + i); // Convert index back to character
            }
        }

        // Display the occurrences of all alphabets
        System.out.println("Occurrences of Alphabets:");
        for (int j = 0; j < 26; j++) {
            if (c[j] > 0) {
                char k = (char) ('a' + j);
                System.out.println(k + ": " + c[j]);
            }
        }

        // Display the alphabet with the maximum occurrence
        System.out.println("Alphabet with Maximum Occurrence: " + h + " (" + g + " occurrences)");

        a.close();
    }
}
