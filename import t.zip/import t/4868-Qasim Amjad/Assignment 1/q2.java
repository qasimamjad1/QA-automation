package qsecond;

import java.util.Scanner;
import q1.q1;

public class qsecond extends q1 {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);

        System.out.print("Enter your full name: ");
        String fullName = sc.nextLine();//input string

        int firstSpaceIndex = fullName.indexOf(' ');
        
        if (firstSpaceIndex != -1 && firstSpaceIndex != fullName.length() - 1) {
            // Extract the first name, middle name initials, and last name
            String[] names = fullName.split(" ");
            String firstName = names[0];
            String middleInitials = "";
            String lastName = names[names.length - 1];

            for (int i = 1; i < names.length - 1; i++) {
                middleInitials += names[i].charAt(0) + ".";
            }

            // Construct the abbreviated name using the extracted components
            String abbreviatedName = firstName.charAt(0) + "." + middleInitials + lastName;

            // Print the abbreviated name
            System.out.println("Abbreviated Name: " + abbreviatedName);
        } else {
            // If the input is invalid, notify the user
            System.out.println("Invalid input. Please enter at least two names.");
        }

        sc.close(); // Close 
    }
}
