public class MaximumAlphabetOccurrences {
    public static void main(String[] args) {
        String input = "your input string with alphabets";
        input = convertToLowercase(input);

        int[] alphabetOccurrences = new int[26];

        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (c >= 'a' && c <= 'z') {
                alphabetOccurrences[c - 'a']++;
            }
        }

        char mostFrequentAlphabet = 'a';
        int maxOccurrence = alphabetOccurrences[0];

        for (int i = 1; i < alphabetOccurrences.length; i++) {
            if (alphabetOccurrences[i] > maxOccurrence) {
                maxOccurrence = alphabetOccurrences[i];
                mostFrequentAlphabet = (char) ('a' + i);
            }
        }

        System.out.println("Occurrences of each alphabet:");
        for (int i = 0; i < alphabetOccurrences.length; i++) {
            char alphabet = (char) ('a' + i);
            int occurrence = alphabetOccurrences[i];
            System.out.println(alphabet + ": " + occurrence);
        }

        System.out.println("Alphabet with maximum occurrence: " + mostFrequentAlphabet + " (" + maxOccurrence + " occurrences)");
    }

    public static String convertToLowercase(String str) {
        char[] chars = str.toCharArray();
        for (int i = 0; i < chars.length; i++) {
            if (chars[i] >= 'A' && chars[i] <= 'Z') {
                chars[i] = (char) (chars[i] + 32);
            }
        }
        return new String(chars);
    }
}
