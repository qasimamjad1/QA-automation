package duplicatecharacters;

public class Q5 {
    public static void main(String[] args) {
        String input = "your input string with duplicates";
        String result = removeDuplicates(input);
        System.out.println("Original String: " + input);
        System.out.println("String after removing duplicates: " + result);
    }

    public static String removeDuplicates(String str) {
        char[] chars = str.toCharArray();
        boolean[] seen = new boolean[128]; // Assuming ASCII characters
        int length = 0;

        for (char c : chars) {
            if (!seen[c]) {
                chars[length] = c;
                seen[c] = true;
                length++;
            }
        }

        char[] resultChars = new char[length];
        System.arraycopy(chars, 0, resultChars, 0, length);

        return new String(resultChars);
    }
}
